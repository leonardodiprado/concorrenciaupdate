require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const app = express();
app.use(express.json());
app.use(express.static('.'));

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// Endpoint para cadastrar cliente
app.post('/cadastrar', async (req, res) => {
    const { nome, limite } = req.body;
    try {
        await pool.query('INSERT INTO clientes (nome, limite_credito) VALUES ($1, $2)', [nome, limite]);
        res.send('Cliente cadastrado com sucesso!');
    } catch (error) {
        res.status(500).send('Erro ao cadastrar cliente');
    }
});

// Endpoint para iniciar atualização do limite
app.put('/atualizar', async (req, res) => {
    const { id, novoLimite } = req.body;
    try {
        // Verifica se o cliente já está em atualização
        const cliente = await pool.query('SELECT * FROM clientes WHERE id = $1', [id]);
        if (cliente.rows.length === 0) {
            return res.json({ sucesso: false, erro: 'Cliente não encontrado' });
        }
        if (cliente.rows[0].atualizando) {
            return res.json({ sucesso: false, erro: 'Limite já está sendo atualizado por outro usuário' });
        }

        // Marca o cliente como em atualização
        await pool.query('UPDATE clientes SET atualizando = TRUE WHERE id = $1', [id]);
        
        // Envia sucesso para abrir o modal de confirmação
        res.json({ sucesso: true });
    } catch (error) {
        res.json({ sucesso: false, erro: 'Erro ao atualizar limite' });
    }
});

// Endpoint para confirmar ou cancelar a atualização
app.put('/confirmarAtualizacao', async (req, res) => {
    const { id, novoLimite, confirmar } = req.body;
    try {
        if (confirmar) {
            // Atualiza o limite de crédito e remove a flag de atualização
            await pool.query('UPDATE clientes SET limite_credito = $1, atualizando = FALSE WHERE id = $2', [novoLimite, id]);
            res.json({ sucesso: true, mensagem: 'Limite atualizado com sucesso' });
        } else {
            // Apenas remove a flag de atualização sem alterar o limite
            await pool.query('UPDATE clientes SET atualizando = FALSE WHERE id = $1', [id]);
            res.json({ sucesso: false, mensagem: 'Atualização cancelada' });
        }
    } catch (error) {
        res.json({ sucesso: false, erro: 'Erro ao confirmar atualização' });
    }
});

// Inicia o servidor
app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});
