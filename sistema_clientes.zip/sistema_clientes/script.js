document.getElementById('formCadastro').onsubmit = async (e) => {
    e.preventDefault();
    const nome = document.getElementById('nome').value;
    const limite = document.getElementById('limite').value;
    const res = await fetch('/cadastrar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, limite })
    });
    document.getElementById('mensagem').innerText = await res.text();
};

document.getElementById('formAtualizar').onsubmit = async (e) => {
    e.preventDefault();
    const id = document.getElementById('idCliente').value;
    const novoLimite = document.getElementById('novoLimite').value;
    const res = await fetch('/atualizar', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, novoLimite })
    });
    const resposta = await res.json();

    if (resposta.sucesso) {
        document.getElementById('modalConfirmacao').style.display = 'block';

        document.getElementById('btnConfirmar').onclick = async () => {
            const resConfirm = await fetch('/confirmarAtualizacao', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, novoLimite, confirmar: true })
            });
            const result = await resConfirm.json();
            alert(result.mensagem);
            document.getElementById('modalConfirmacao').style.display = 'none';
        };

        document.getElementById('btnCancelar').onclick = async () => {
            const resCancel = await fetch('/confirmarAtualizacao', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, confirmar: false })
            });
            const result = await resCancel.json();
            alert(result.mensagem);
            document.getElementById('modalConfirmacao').style.display = 'none';
        };
    } else {
        alert(`Erro: ${resposta.erro}`);
    }
};
